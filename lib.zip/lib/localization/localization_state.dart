abstract class LocalizationState {}

class LocalizationInitialState extends LocalizationState {}

class LocalizationChangeState extends LocalizationState {}