

abstract class MyTripStates{}

class MyTripInitialState extends MyTripStates{}

class Choice1Updated extends MyTripStates{}
class Choice2Updated extends MyTripStates{}