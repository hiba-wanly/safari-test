abstract class  AppState {}

class AppInitialState extends AppState {}

class AppChangeBottomNabBarState extends AppState {}

class LoadedScreenApp extends AppState {}

class loadingScreenApp extends AppState {}


