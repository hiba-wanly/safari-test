abstract class  ColorState {}

class ColorInitialState extends ColorState {}

class ColorChangeState extends ColorState {}