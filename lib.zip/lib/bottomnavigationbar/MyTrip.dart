// import 'package:flutter/material.dart';
// class MyTrip extends StatelessWidget {
//   const MyTrip({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           'trip',
//
//         ),
//         actions: <Widget>[
//           IconButton(
//             icon: Icon(
//               Icons.favorite,
//
//             ),
//             onPressed: (){
//             },
//           ),
//         ],
//       ),
//       body: Center(
//         child: Text(
//           'my trip',
//         ),
//       ),
//     );
//   }
// }